import unittest
import os
import json
import sqlite3

import database
import ml_engine
from app import app

class PlayerPulseTestCase(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True
        database.init_db()

    def test_database_init(self):
        """Test database tables creation."""
        conn = sqlite3.connect(database.DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = [row[0] for row in cursor.fetchall()]
        conn.close()
        
        self.assertIn('datasets', tables)
        self.assertIn('models', tables)
        self.assertIn('predictions', tables)

    def test_dashboard_stats_endpoint(self):
        """Test /api/stats endpoint response structure."""
        response = self.app.get('/api/stats')
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        
        self.assertIn('counts', data)
        self.assertIn('has_model', data)
        self.assertIn('chart_data', data)

    def test_dataset_info_endpoint(self):
        """Test /api/dataset endpoint."""
        response = self.app.get('/api/dataset')
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertTrue(data.get('loaded', False))
        self.assertIn('columns', data)
        self.assertIn('preview', data)

    def test_ml_engine_training(self):
        """Test ml_engine training pipeline on sample cricket dataset."""
        sample_csv = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sample_cricket_data.csv')
        self.assertTrue(os.path.exists(sample_csv))
        
        result = ml_engine.train_and_evaluate(sample_csv, target_col='next_match_runs')
        self.assertIn('task_type', result)
        self.assertIn('best_model', result)
        self.assertIn('gb_metrics', result)
        self.assertIn('xgb_metrics', result)

    def test_ml_engine_prediction(self):
        """Test ml_engine predict_performance function."""
        sample_csv = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sample_cricket_data.csv')
        res = ml_engine.train_and_evaluate(sample_csv, target_col='next_match_runs')
        
        sample_input = {
            'matches_played': 280,
            'runs': 13000,
            'batting_average': 58.5,
            'strike_rate': 93.2,
            'hundreds': 47,
            'fifties': 68,
            'wickets': 4,
            'bowling_average': 166.0,
            'economy_rate': 6.2,
            'catches': 140
        }
        
        pred = ml_engine.predict_performance(sample_input, model_choice='both')
        self.assertIn('predictions', pred)
        self.assertIn('gb', pred['predictions'])
        self.assertIn('xgb', pred['predictions'])

if __name__ == '__main__':
    unittest.main()
