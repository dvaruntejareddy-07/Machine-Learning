# PlayerPulse - Player Performance Prediction Using XGBoost and Gradient Boosting

**PlayerPulse** is a complete, modern, full-stack machine learning sports analytics platform built for predicting cricket player future match performances, training and comparing Machine Learning algorithms (Gradient Boosting vs XGBoost), comparing players side-by-side, and conducting interactive **"What-If" Sensitivity Simulations**.

---

## 🌟 Features & Pages

1. **Home (`/`)**: Project title, summary, action buttons (Upload Dataset, Predict Performance, Compare Players), and feature cards.
2. **Dashboard (`/dashboard`)**: Key metric indicators (Player count, dataset records, trained models, saved predictions) and interactive Chart.js visualizations.
3. **Dataset (`/dataset`)**: CSV upload interface, downloadable CSV template, row preview table, column data type report, missing value check, and target column selection with description. Pre-loaded with clearly labeled **Sample Data** (`sample_cricket_data.csv`).
4. **Model Training & Evaluation (`/train`)**: Trains **Gradient Boosting** and **XGBoost** side-by-side with leakage prevention (chronological split on date columns). Displays MAE, MSE, RMSE, R² (for regression) or Accuracy, Precision, Recall, F1, and Confusion Matrix (for classification), measured training times, feature importance chart, and recommended **Best Model** badge.
5. **Predict Performance (`/predict`)**: Select an existing dataset player or manually enter statistics. Choose Gradient Boosting, XGBoost, or Both for side-by-side predictions with formatted units (e.g. `48.5 Runs`, `2.4 Wickets`) and auto-saves to SQLite history.
6. **Compare Players (`/compare`)**: Select 2 to 4 players to compare statistics, career metrics, and future performance predictions in a comparative table.
7. **What-If Simulator (`/simulator`) [MAIN FEATURE]**: Select a base player, adjust statistics using interactive range sliders, and compare original vs modified predictions in real-time with visual input highlights and sensitivity disclaimers.
8. **Prediction History (`/history`)**: Searchable, filterable log of saved player predictions with CSV Export functionality.
9. **About Project (`/about`)**: Simple English explanations of project objective, workflow architecture, mathematical breakdown of Gradient Boosting vs XGBoost, target definitions, and model evaluation metrics.

---

## 🛠️ Technology Stack

- **Frontend**: HTML5, Vanilla CSS3 (Dark Navy `#0b132b` & Emerald Green `#10b981`), JavaScript (ES6+), Bootstrap 5, Chart.js, FontAwesome 6.
- **Backend**: Python Flask REST API framework.
- **Data Processing**: Pandas, NumPy.
- **Machine Learning**: Scikit-Learn (Gradient Boosting) & XGBoost (with dual-mode fallback engine for Windows environment compatibility).
- **Database**: SQLite3 (`playerpulse.db`).

---

## 🚀 Step-by-Step Instructions to Run in VS Code

### Prerequisites
- Python 3.8+ installed on your computer.
- Visual Studio Code (VS Code).

### Step 1: Open Project in VS Code
1. Open VS Code.
2. Go to **File -> Open Folder...** and select `c:\Users\teja\OneDrive\Desktop\ML PROJECT` (or your project directory).

### Step 2: Open Terminal in VS Code
1. Press `Ctrl + ~` (or go to **Terminal -> New Terminal**).

### Step 3: Create and Activate Virtual Environment (Optional but Recommended)
```bash
# Create virtual environment
python -m venv venv

# Activate on Windows (PowerShell)
.\venv\Scripts\Activate.ps1

# Or activate on Windows (Command Prompt)
venv\Scripts\activate.bat
```

### Step 4: Install Required Packages
```bash
pip install -r requirements.txt
```

### Step 5: Start the PlayerPulse Flask Application
```bash
python app.py
```

### Step 6: Access the Application in Your Browser
Open your web browser (Chrome, Edge, Firefox) and navigate to:
```
http://127.0.0.1:5000
```

---

## 📁 Directory Structure

```
ML PROJECT/
├── app.py                     # Main Flask REST API & Web Server
├── database.py                # SQLite database setup & CRUD operations
├── ml_engine.py               # Preprocessing, ML model training (GB & XGB), evaluation & inference
├── sample_cricket_data.csv    # Pre-loaded sample cricket player dataset
├── requirements.txt           # Python package dependencies
├── README.md                  # Project documentation & instructions
├── data/                      # Directory for uploaded CSV datasets
├── models/                    # Saved trained model pipelines & metadata
├── static/
│   ├── css/
│   │   └── style.css          # Dark Navy & Emerald Green stylesheet
│   └── js/
│       └── main.js            # Frontend interactive JS & Chart.js logic
└── templates/
    └── index.html             # Full responsive Single-Page Web application
```

---

## 🏆 Notes on Model Selection
The application automatically benchmarks Gradient Boosting against XGBoost and dynamically highlights the **Best Model** based on test performance metrics (R² score for numerical predictions or F1-Score for categorical predictions). XGBoost is not assumed to win automatically, ensuring empirical evaluation.
