@echo off
set PYTHON_EXE=C:\Users\ADMIN\AppData\Local\Python\bin\python.exe
if not exist "%PYTHON_EXE%" (
    set PYTHON_EXE=python
)
start "PlayerPulse Server" "%PYTHON_EXE%" app.py
timeout /t 2 /nobreak >nul
start http://127.0.0.1:5001
