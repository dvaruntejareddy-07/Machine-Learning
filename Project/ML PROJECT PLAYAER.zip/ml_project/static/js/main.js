// PlayerPulse Interactive Controller (Fresh Light Theme)
document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    loadStats();
    loadDatasetInfo();
    loadModelInfo();
    loadPlayerDropdowns();
    loadHistory();

    // Event Listeners
    document.getElementById('csvUploadForm')?.addEventListener('submit', handleCSVUpload);
    document.getElementById('targetSelectForm')?.addEventListener('submit', handleTargetSelect);
    document.getElementById('trainModelsBtn')?.addEventListener('click', handleTrainModels);
    document.getElementById('predictForm')?.addEventListener('submit', handlePredict);
    document.getElementById('simulatorPlayerSelect')?.addEventListener('change', handleSimulatorPlayerSelect);
    document.getElementById('runSimulatorBtn')?.addEventListener('click', handleRunSimulator);
    document.getElementById('compareForm')?.addEventListener('submit', handleComparePlayers);
    document.getElementById('historySearchInput')?.addEventListener('input', filterHistory);
});

// Global Chart Storage
let dashboardCharts = {};
let trainChart = null;
let compareChart = null;

// Global Data Caches
let globalPlayers = [];
let currentDataset = null;
let currentModelMeta = null;

// Toast Notification Helper
function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `alert alert-${type} shadow-lg text-dark fw-bold border-0 mb-2 fade show`;
    toast.style.minWidth = '280px';
    toast.style.borderRadius = '12px';
    toast.style.background = type === 'success' ? '#D1FAE5' : type === 'warning' ? '#FEF3C7' : '#F3E8FF';
    toast.style.color = type === 'success' ? '#065F46' : type === 'warning' ? '#92400E' : '#5B21B6';
    toast.innerHTML = `<i class="fas fa-${type === 'success' ? 'check-circle' : 'info-circle'} me-2"></i> ${message}`;

    container.appendChild(toast);
    setTimeout(() => {
        toast.remove();
    }, 4000);
}

// Page Navigation
function navigateTo(pageId) {
    document.querySelectorAll('.page-section').forEach(sec => sec.classList.remove('active'));
    document.querySelectorAll('.nav-link-custom').forEach(link => link.classList.remove('active'));

    const targetSection = document.getElementById(`page-${pageId}`);
    const targetLink = document.querySelector(`.nav-link-custom[data-page="${pageId}"]`);

    if (targetSection) {
        targetSection.classList.add('active');
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    if (targetLink) {
        targetLink.classList.add('active');
    }

    // Refresh page specific content
    if (pageId === 'dashboard') loadStats();
    if (pageId === 'dataset') loadDatasetInfo();
    if (pageId === 'train') loadModelInfo();
    if (pageId === 'predict') setupPredictForm();
    if (pageId === 'simulator') setupSimulatorForm();
    if (pageId === 'compare') setupCompareForm();
    if (pageId === 'history') loadHistory();
}

function initNavigation() {
    document.querySelectorAll('[data-page]').forEach(el => {
        el.addEventListener('click', (e) => {
            e.preventDefault();
            const page = el.getAttribute('data-page');
            navigateTo(page);
        });
    });
}

// Fetch Global Dashboard Stats
async function loadStats() {
    try {
        const res = await fetch('/api/stats');
        const data = await res.json();

        document.getElementById('count-players').textContent = data.counts.row_count || 0;
        document.getElementById('count-dataset').textContent = data.counts.row_count || 0;
        document.getElementById('count-models').textContent = data.counts.models_count || 0;
        document.getElementById('count-predictions').textContent = data.counts.predictions_count || 0;

        if (data.latest_dataset) {
            document.getElementById('status-dataset-name').textContent = data.latest_dataset.filename;
            document.getElementById('status-target-col').textContent = data.latest_dataset.target_col || 'next_match_runs';
        }

        if (data.latest_model) {
            document.getElementById('status-best-model').textContent = data.latest_model.best_model || 'Trained';
        }

        if (data.chart_data && data.chart_data.labels.length > 0) {
            renderDashboardCharts(data.chart_data);
        }
    } catch (err) {
        console.error("Error loading stats:", err);
    }
}

// Render Dashboard Analytics Charts
function renderDashboardCharts(chartData) {
    // 1. Top Performers Runs Chart
    const ctxRuns = document.getElementById('chartTopRuns')?.getContext('2d');
    if (ctxRuns) {
        if (dashboardCharts.runs) dashboardCharts.runs.destroy();
        dashboardCharts.runs = new Chart(ctxRuns, {
            type: 'bar',
            data: {
                labels: chartData.labels,
                datasets: [{
                    label: 'Total Career Runs',
                    data: chartData.runs,
                    backgroundColor: 'rgba(109, 40, 217, 0.85)',
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { labels: { color: '#1F2937', font: { weight: 'bold' } } } },
                scales: {
                    x: { ticks: { color: '#4B5563' }, grid: { display: false } },
                    y: { ticks: { color: '#4B5563' }, grid: { color: '#E5E7EB' } }
                }
            }
        });
    }

    // 2. Batting Average & Wickets Chart
    const ctxAvg = document.getElementById('chartAvgWickets')?.getContext('2d');
    if (ctxAvg) {
        if (dashboardCharts.avg) dashboardCharts.avg.destroy();
        dashboardCharts.avg = new Chart(ctxAvg, {
            type: 'line',
            data: {
                labels: chartData.labels,
                datasets: [
                    {
                        label: 'Batting Average',
                        data: chartData.avg,
                        borderColor: '#6D28D9',
                        backgroundColor: 'rgba(109, 40, 217, 0.1)',
                        fill: true,
                        tension: 0.3
                    },
                    {
                        label: 'Wickets',
                        data: chartData.wickets,
                        borderColor: '#F97316',
                        backgroundColor: 'rgba(249, 115, 22, 0.1)',
                        fill: true,
                        tension: 0.3
                    }
                ]
            },
            options: {
                responsive: true,
                plugins: { legend: { labels: { color: '#1F2937', font: { weight: 'bold' } } } },
                scales: {
                    x: { ticks: { color: '#4B5563' }, grid: { display: false } },
                    y: { ticks: { color: '#4B5563' }, grid: { color: '#E5E7EB' } }
                }
            }
        });
    }
}

// Load & Render Dataset Info
async function loadDatasetInfo() {
    try {
        const res = await fetch('/api/dataset');
        const data = await res.json();

        if (!data.loaded) return;

        currentDataset = data;

        document.getElementById('ds-filename').textContent = data.filename;
        document.getElementById('ds-rows').textContent = data.row_count;
        document.getElementById('ds-cols').textContent = data.col_count;
        document.getElementById('ds-target-badge').textContent = data.target_col || 'next_match_runs';

        // Sample & Synthetic Data Tag Toggle
        const sampleTag = document.getElementById('ds-sample-tag');
        const synthAlert = document.getElementById('syntheticDataAlert');
        const isSynth = data.is_sample || (data.filename && (data.filename.toLowerCase().includes('synthetic') || data.filename.toLowerCase().includes('sample')));

        if (sampleTag) sampleTag.style.display = isSynth ? 'inline-block' : 'none';
        if (synthAlert) {
            if (isSynth) synthAlert.classList.remove('d-none');
            else synthAlert.classList.add('d-none');
        }

        // Target Select Options Render
        const targetSelect = document.getElementById('targetColSelect');
        if (targetSelect && data.columns && data.columns.length > 0) {
            targetSelect.innerHTML = '';
            
            let activeTarget = data.target_col;
            if (data.columns.includes('next_match_runs')) {
                activeTarget = 'next_match_runs';
            } else if (!activeTarget || !data.columns.includes(activeTarget)) {
                activeTarget = data.columns[data.columns.length - 1];
            }

            data.columns.forEach(col => {
                const opt = document.createElement('option');
                opt.value = col;
                opt.textContent = col;
                opt.style.color = '#1F2937';
                opt.style.backgroundColor = '#FFFFFF';
                if (col === activeTarget) opt.selected = true;
                targetSelect.appendChild(opt);
            });
            targetSelect.value = activeTarget;
        }

        if (document.getElementById('targetDescInput')) {
            document.getElementById('targetDescInput').value = data.target_desc || "Predict runs scored in the next match";
        }

        // Render Missing Values Summary
        const missingBox = document.getElementById('missingValuesReport');
        if (missingBox) {
            let missingHtml = '<div class="row g-2">';
            let hasMissing = false;
            for (let [col, count] of Object.entries(data.missing_values || {})) {
                if (count > 0) {
                    hasMissing = true;
                    missingHtml += `<div class="col-md-4"><div class="p-2 rounded bg-light border text-danger small"><strong>${col}</strong>: ${count} missing</div></div>`;
                }
            }
            if (!hasMissing) {
                missingHtml += '<div class="col-12"><div class="p-2 rounded bg-light border text-success small"><i class="fas fa-check-circle me-1"></i> No missing values detected in dataset.</div></div>';
            }
            missingHtml += '</div>';
            missingBox.innerHTML = missingHtml;
        }

        renderDatasetTable(data.columns, data.preview);

    } catch (err) {
        console.error("Error loading dataset:", err);
    }
}

function renderDatasetTable(columns, rows) {
    const thead = document.getElementById('datasetTableHead');
    const tbody = document.getElementById('datasetTableBody');

    if (!thead || !tbody) return;

    thead.innerHTML = `<tr>${columns.map(c => `<th>${c}</th>`).join('')}</tr>`;
    tbody.innerHTML = rows.map(r => `
        <tr>${columns.map(c => `<td>${r[c] !== null && r[c] !== undefined ? r[c] : '<span class="text-muted">-</span>'}</td>`).join('')}</tr>
    `).join('');
}

// Upload CSV Form Handler
async function handleCSVUpload(e) {
    e.preventDefault();
    const fileInput = document.getElementById('csvFileInput');
    if (!fileInput.files.length) {
        showToast('Please select a CSV file first.', 'warning');
        return;
    }

    const formData = new FormData();
    formData.append('file', fileInput.files[0]);

    const msgBox = document.getElementById('uploadMsg');
    msgBox.innerHTML = '<div class="spinner-border spinner-border-sm text-purple me-2"></div> Uploading and parsing CSV...';

    try {
        const res = await fetch('/api/dataset/upload', { method: 'POST', body: formData });
        const data = await res.json();

        if (res.ok) {
            showToast(data.message, 'success');
            msgBox.innerHTML = `<div class="alert alert-success p-2 small"><i class="fas fa-check-circle me-1"></i> ${data.message}</div>`;
            await loadDatasetInfo();
            await loadStats();
            await loadPlayerDropdowns();
        } else {
            msgBox.innerHTML = `<div class="alert alert-danger p-2 small"><i class="fas fa-exclamation-triangle me-1"></i> ${data.error}</div>`;
        }
    } catch (err) {
        msgBox.innerHTML = `<div class="alert alert-danger p-2 small">Upload failed: ${err.message}</div>`;
    }
}

// Select Target Column Handler
async function handleTargetSelect(e) {
    e.preventDefault();
    const targetSelect = document.getElementById('targetColSelect');
    const target_col = targetSelect ? targetSelect.value : '';
    const target_desc = document.getElementById('targetDescInput') ? document.getElementById('targetDescInput').value : 'Predict runs scored in the next match';

    if (!target_col || target_col.trim() === '') {
        showToast('Target column cannot be empty. Please select a valid column.', 'warning');
        return;
    }

    try {
        const res = await fetch('/api/dataset/target', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ target_col, target_desc })
        });
        const data = await res.json();
        if (res.ok) {
            showToast(data.message, 'success');
            await loadDatasetInfo();
            await loadStats();
        } else {
            showToast(data.error || 'Failed to update target column.', 'danger');
        }
    } catch (err) {
        showToast('Failed to update target column.', 'danger');
    }
}

// Load Synthetic Sample CSV Button
async function loadSampleDataset() {
    try {
        const res = await fetch('/api/dataset/load-sample', { method: 'POST' });
        const data = await res.json();
        if (res.ok) {
            showToast(data.message, 'success');
            await loadDatasetInfo();
            await loadStats();
            await loadPlayerDropdowns();
        }
    } catch (err) {
        showToast('Failed to load sample dataset.', 'danger');
    }
}

// Load Model Info & Benchmark Results
async function loadModelInfo() {
    try {
        const res = await fetch('/api/models/latest');
        const data = await res.json();

        const noAlert = document.getElementById('noModelAlert');
        const contentBox = document.getElementById('modelResultsContent');

        if (!data.has_model) {
            if (noAlert) noAlert.style.display = 'block';
            if (contentBox) contentBox.style.display = 'none';
            return;
        }

        if (noAlert) noAlert.style.display = 'none';
        if (contentBox) contentBox.style.display = 'block';

        currentModelMeta = data.model;
        const m = data.model;

        // Render Recommended Best Model Banner
        const bestBanner = document.getElementById('bestModelBanner');
        if (bestBanner) {
            bestBanner.innerHTML = `
                <div class="p-3 rounded-3 d-flex align-items-center justify-content-between" style="background: #F3E8FF; border: 2px solid var(--primary-purple);">
                    <div>
                        <span class="badge bg-purple text-white mb-1">Recommended Best Model</span>
                        <h4 class="fw-bold text-purple mb-0"><i class="fas fa-trophy text-orange me-2"></i> ${m.best_model}</h4>
                        <small class="text-muted">${m.best_reason || 'Evaluated based on test dataset RMSE & R² score'}</small>
                    </div>
                    <div class="text-end">
                        <span class="badge badge-purple">Target: ${m.target_col}</span>
                    </div>
                </div>
            `;
        }

        document.getElementById('eval-split').textContent = m.split_type || 'Chronological Train-Test Split (80/20)';

        // Render Evaluation Table
        const gb = m.gb_metrics || {};
        const xgb = m.xgb_metrics || {};
        const tbody = document.getElementById('metricsTableBody');

        if (tbody) {
            tbody.innerHTML = `
                <tr>
                    <td><strong>Mean Absolute Error (MAE)</strong> <i class="fas fa-circle-info text-muted ms-1" title="Average prediction error magnitude"></i></td>
                    <td class="fw-bold ${m.best_model === 'Gradient Boosting' ? 'text-purple' : ''}">${gb.mae || 0.0}</td>
                    <td class="fw-bold ${m.best_model === 'XGBoost' ? 'text-purple' : ''}">${xgb.mae || 0.0}</td>
                </tr>
                <tr>
                    <td><strong>Root Mean Squared Error (RMSE)</strong> <i class="fas fa-circle-info text-muted ms-1" title="Standard deviation of residuals"></i></td>
                    <td class="fw-bold ${m.best_model === 'Gradient Boosting' ? 'text-purple' : ''}">${gb.rmse || 0.0}</td>
                    <td class="fw-bold ${m.best_model === 'XGBoost' ? 'text-purple' : ''}">${xgb.rmse || 0.0}</td>
                </tr>
                <tr>
                    <td><strong>R² Score (Coeff. of Determination)</strong> <i class="fas fa-circle-info text-muted ms-1" title="Variance explained by model"></i></td>
                    <td class="fw-bold ${m.best_model === 'Gradient Boosting' ? 'text-purple' : ''}">${gb.r2 || 0.0}</td>
                    <td class="fw-bold ${m.best_model === 'XGBoost' ? 'text-purple' : ''}">${xgb.r2 || 0.0}</td>
                </tr>
                <tr>
                    <td><strong>Training Execution Time</strong></td>
                    <td>${gb.train_time_ms || 0} ms</td>
                    <td>${xgb.train_time_ms || 0} ms</td>
                </tr>
            `;
        }

        if (m.feature_importance && m.feature_importance.length > 0) {
            renderFeatureImportanceChart(m.feature_importance);
        }

    } catch (err) {
        console.error("Error loading model info:", err);
    }
}

// Train Both Models Form Handler
async function handleTrainModels() {
    const statusBox = document.getElementById('trainStatusBox');
    statusBox.innerHTML = '<div class="alert alert-purple"><div class="spinner-border spinner-border-sm me-2"></div> Training Gradient Boosting & XGBoost models on chronological split...</div>';

    try {
        const res = await fetch('/api/train', { method: 'POST' });
        const data = await res.json();

        if (res.ok) {
            showToast(data.message, 'success');
            statusBox.innerHTML = `<div class="alert alert-success"><i class="fas fa-check-circle me-1"></i> ${data.message}</div>`;
            await loadModelInfo();
            await loadStats();
        } else {
            statusBox.innerHTML = `<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-1"></i> ${data.error}</div>`;
        }
    } catch (err) {
        statusBox.innerHTML = `<div class="alert alert-danger">Training error: ${err.message}</div>`;
    }
}

// Render Feature Importance Chart
function renderFeatureImportanceChart(impData) {
    const ctx = document.getElementById('chartFeatureImportance')?.getContext('2d');
    if (!ctx) return;

    if (trainChart) trainChart.destroy();

    const labels = impData.map(d => d.feature);
    const scores = impData.map(d => d.importance);

    trainChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Relative Feature Importance',
                data: scores,
                backgroundColor: 'rgba(109, 40, 217, 0.85)',
                borderRadius: 6
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            plugins: { legend: { labels: { color: '#1F2937', font: { weight: 'bold' } } } },
            scales: {
                x: { ticks: { color: '#4B5563' }, grid: { color: '#E5E7EB' } },
                y: { ticks: { color: '#4B5563' }, grid: { display: false } }
            }
        }
    });
}

// Load Player Dropdowns across views
async function loadPlayerDropdowns() {
    try {
        const res = await fetch('/api/players');
        const data = await res.json();
        globalPlayers = data.players || [];

        // Populate Predict Player Dropdown
        const predSelect = document.getElementById('predictPlayerSelect');
        if (predSelect) {
            predSelect.innerHTML = '<option value="">-- Choose Existing Player or Enter Manually --</option>';
            globalPlayers.forEach(p => {
                const opt = document.createElement('option');
                opt.value = p.player_name;
                opt.textContent = `${p.player_name} (${p.role} - ${p.match_format})`;
                opt.style.color = '#1F2937';
                predSelect.appendChild(opt);
            });
            predSelect.removeEventListener('change', onPredictPlayerSelect);
            predSelect.addEventListener('change', onPredictPlayerSelect);
        }

        setupComparePlayerOptions();

    } catch (err) {
        console.error("Error loading players:", err);
    }
}

// Auto-fill form when player selected in Predict page
function onPredictPlayerSelect() {
    const selectedName = document.getElementById('predictPlayerSelect').value;
    if (!selectedName) return;

    const player = globalPlayers.find(p => p.player_name === selectedName);
    if (!player) return;

    for (let [key, val] of Object.entries(player)) {
        const input = document.getElementById(`input_feat_${key}`);
        if (input) {
            input.value = val !== null && val !== undefined ? val : '';
        }
    }
}

// Setup Predict Form Fields
async function setupPredictForm() {
    const container = document.getElementById('dynamicFeatureFields');
    if (!container) return;

    if (!currentModelMeta) {
        const res = await fetch('/api/models/latest');
        const data = await res.json();
        if (data.has_model) currentModelMeta = data.model;
    }

    if (!currentModelMeta) {
        container.innerHTML = '<div class="alert alert-warning"><i class="fas fa-exclamation-circle me-2"></i> No trained model found. Please train models on the Training page first.</div>';
        return;
    }

    const features = currentModelMeta.feature_names || [];
    let html = '<div class="row g-3">';

    features.forEach(f => {
        if (f.startsWith('next_') || f.startsWith('target_')) return;
        const prettyName = f.replace(/_/g, ' ').toUpperCase();

        if (f === 'role') {
            html += `
                <div class="col-md-6 col-lg-4">
                    <label class="form-label mb-1">${prettyName}</label>
                    <select class="form-select form-select-light fw-bold" id="input_feat_${f}">
                        <option value="Batsman">Batsman</option>
                        <option value="Bowler">Bowler</option>
                        <option value="All-Rounder">All-Rounder</option>
                        <option value="Wicket-Keeper">Wicket-Keeper</option>
                    </select>
                </div>
            `;
        } else if (f === 'match_format') {
            html += `
                <div class="col-md-6 col-lg-4">
                    <label class="form-label mb-1">${prettyName}</label>
                    <select class="form-select form-select-light fw-bold" id="input_feat_${f}">
                        <option value="ODI">ODI</option>
                        <option value="Test">Test</option>
                        <option value="T20">T20</option>
                    </select>
                </div>
            `;
        } else {
            html += `
                <div class="col-md-6 col-lg-4">
                    <label class="form-label mb-1">${prettyName}</label>
                    <input type="number" step="any" class="form-control form-control-light" id="input_feat_${f}" placeholder="0.0">
                </div>
            `;
        }
    });
    html += '</div>';
    container.innerHTML = html;
}

// Predict Submit Handler
async function handlePredict(e) {
    e.preventDefault();
    if (!currentModelMeta) {
        showToast('Please train a model first.', 'warning');
        return;
    }

    const playerSelect = document.getElementById('predictPlayerSelect');
    const playerName = playerSelect && playerSelect.value ? playerSelect.value : 'Custom Player';
    const modelChoice = document.getElementById('predictModelChoice').value;

    const inputStats = {};
    const features = currentModelMeta.feature_names || [];
    features.forEach(f => {
        const el = document.getElementById(`input_feat_${f}`);
        if (el) {
            if (f === 'role' || f === 'match_format') {
                inputStats[f] = el.value || 'Batsman';
            } else {
                inputStats[f] = el.value !== '' ? parseFloat(el.value) : 0;
            }
        }
    });

    const resultBox = document.getElementById('predictResultBox');
    resultBox.innerHTML = '<div class="p-4 text-center"><div class="spinner-border text-purple me-2"></div> Generating AI prediction...</div>';

    try {
        const res = await fetch('/api/predict', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                player_name: playerName,
                model_choice: modelChoice,
                input_stats: inputStats
            })
        });

        const data = await res.json();
        if (res.ok) {
            renderPredictResult(data.result);
            await loadHistory();
            await loadStats();
        } else {
            resultBox.innerHTML = `<div class="alert alert-danger">${data.error}</div>`;
        }
    } catch (err) {
        resultBox.innerHTML = `<div class="alert alert-danger">Prediction error: ${err.message}</div>`;
    }
}

function renderPredictResult(res) {
    const box = document.getElementById('predictResultBox');
    if (!box) return;

    const preds = res.predictions;
    let html = '<div class="row g-3 mt-2">';

    if (preds.gb) {
        html += `
            <div class="col-md-${preds.xgb ? '6' : '12'}">
                <div class="p-3 text-center rounded-3" style="background: #F3E8FF; border: 2px solid var(--primary-purple);">
                    <span class="badge bg-purple text-white mb-2">Gradient Boosting</span>
                    <h2 class="metric-number text-purple mb-1">${preds.gb.formatted}</h2>
                    <p class="text-muted small mb-0">Predicted ${res.target_col}</p>
                </div>
            </div>
        `;
    }

    if (preds.xgb) {
        html += `
            <div class="col-md-${preds.gb ? '6' : '12'}">
                <div class="p-3 text-center rounded-3" style="background: #FFEDD5; border: 2px solid var(--orange);">
                    <span class="badge bg-orange text-white mb-2">XGBoost</span>
                    <h2 class="metric-number text-orange mb-1">${preds.xgb.formatted}</h2>
                    <p class="text-muted small mb-0">Predicted ${res.target_col}</p>
                </div>
            </div>
        `;
    }

    html += '</div>';

    html += `
        <div class="alert alert-info border-info mt-3 p-2 small">
            <i class="fas fa-info-circle me-1"></i> Predictions represent statistical estimates based on historical player records and model training.
        </div>
    `;

    box.innerHTML = html;
}

// Player Comparison Setup
function setupComparePlayerOptions() {
    const p1 = document.getElementById('comparePlayer1');
    const p2 = document.getElementById('comparePlayer2');

    if (!p1 || !p2) return;

    p1.innerHTML = '<option value="">-- Choose Player 1 --</option>';
    p2.innerHTML = '<option value="">-- Choose Player 2 --</option>';

    globalPlayers.forEach(p => {
        const opt1 = document.createElement('option');
        opt1.value = p.player_name;
        opt1.textContent = `${p.player_name} (${p.role})`;
        p1.appendChild(opt1);

        const opt2 = document.createElement('option');
        opt2.value = p.player_name;
        opt2.textContent = `${p.player_name} (${p.role})`;
        p2.appendChild(opt2);
    });

    if (globalPlayers.length >= 2) {
        p1.selectedIndex = 1;
        p2.selectedIndex = 2;
    }
}

function setupCompareForm() {
    setupComparePlayerOptions();
}

async function handleComparePlayers(e) {
    e.preventDefault();
    const p1Name = document.getElementById('comparePlayer1').value;
    const p2Name = document.getElementById('comparePlayer2').value;

    if (!p1Name || !p2Name) {
        showToast('Please select two players to compare.', 'warning');
        return;
    }

    try {
        const res = await fetch('/api/compare', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ player1: p1Name, player2: p2Name })
        });

        const data = await res.json();
        if (res.ok) {
            renderCompareResults(data);
        }
    } catch (err) {
        showToast('Error comparing players.', 'danger');
    }
}

function renderCompareResults(data) {
    const container = document.getElementById('compareResultContent');
    if (container) container.style.display = 'block';

    const p1 = data.player1;
    const p2 = data.player2;

    document.getElementById('comp-p1-head').textContent = p1.player_name;
    document.getElementById('comp-p2-head').textContent = p2.player_name;

    const tbody = document.getElementById('compareTableBody');
    const keys = ['matches_played', 'runs', 'batting_average', 'strike_rate', 'wickets', 'bowling_average', 'economy_rate'];

    let html = '';
    keys.forEach(k => {
        const label = k.replace(/_/g, ' ').toUpperCase();
        html += `
            <tr>
                <td><strong>${label}</strong></td>
                <td>${p1[k] !== undefined ? p1[k] : '-'}</td>
                <td>${p2[k] !== undefined ? p2[k] : '-'}</td>
            </tr>
        `;
    });

    html += `
        <tr class="table-primary">
            <td><strong>PREDICTED NEXT MATCH RUNS (GB)</strong></td>
            <td class="fw-bold text-purple">${data.p1_pred.gb ? data.p1_pred.gb.formatted : '-'}</td>
            <td class="fw-bold text-purple">${data.p2_pred.gb ? data.p2_pred.gb.formatted : '-'}</td>
        </tr>
        <tr class="table-warning">
            <td><strong>PREDICTED NEXT MATCH RUNS (XGB)</strong></td>
            <td class="fw-bold text-orange">${data.p1_pred.xgb ? data.p1_pred.xgb.formatted : '-'}</td>
            <td class="fw-bold text-orange">${data.p2_pred.xgb ? data.p2_pred.xgb.formatted : '-'}</td>
        </tr>
    `;
    tbody.innerHTML = html;

    // Chart visualizer
    const ctx = document.getElementById('chartComparePlayers')?.getContext('2d');
    if (ctx) {
        if (compareChart) compareChart.destroy();
        const p1Val = data.p1_pred.gb ? data.p1_pred.gb.value : 0;
        const p2Val = data.p2_pred.gb ? data.p2_pred.gb.value : 0;

        compareChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: [p1.player_name, p2.player_name],
                datasets: [{
                    label: 'Predicted Next Match Runs',
                    data: [p1Val, p2Val],
                    backgroundColor: ['rgba(109, 40, 217, 0.85)', 'rgba(249, 115, 22, 0.85)'],
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } },
                scales: {
                    x: { ticks: { color: '#1F2937', font: { weight: 'bold' } } },
                    y: { ticks: { color: '#4B5563' }, grid: { color: '#E5E7EB' } }
                }
            }
        });
    }
}

// What-If Simulator Setup
function setupSimulatorForm() {
    const select = document.getElementById('simulatorPlayerSelect');
    if (!select) return;

    select.innerHTML = '<option value="">-- Choose Base Player for What-If Simulation --</option>';
    globalPlayers.forEach(p => {
        const opt = document.createElement('option');
        opt.value = p.player_name;
        opt.textContent = `${p.player_name} (${p.role})`;
        select.appendChild(opt);
    });

    if (globalPlayers.length > 0) {
        select.selectedIndex = 1;
        handleSimulatorPlayerSelect();
    }
}

function handleSimulatorPlayerSelect() {
    const pName = document.getElementById('simulatorPlayerSelect').value;
    if (!pName) return;

    const player = globalPlayers.find(p => p.player_name === pName);
    if (!player) return;

    const container = document.getElementById('simulatorSlidersContainer');
    if (!container) return;

    const simFields = [
        { key: 'batting_average', min: 10, max: 80, step: 0.5, label: 'Batting Average' },
        { key: 'strike_rate', min: 50, max: 200, step: 1, label: 'Strike Rate' },
        { key: 'runs', min: 100, max: 15000, step: 100, label: 'Total Career Runs' },
        { key: 'recent_form_score', min: 40, max: 100, step: 1, label: 'Recent Form Index' }
    ];

    let html = '';
    simFields.forEach(f => {
        const val = player[f.key] !== undefined ? player[f.key] : (f.min + f.max) / 2;
        html += `
            <div class="mb-3">
                <div class="d-flex justify-content-between">
                    <label class="form-label mb-1">${f.label}</label>
                    <span class="fw-bold text-purple" id="val_sim_${f.key}">${val}</span>
                </div>
                <input type="range" class="custom-slider" id="sim_${f.key}" min="${f.min}" max="${f.max}" step="${f.step}" value="${val}" oninput="document.getElementById('val_sim_${f.key}').textContent = this.value">
            </div>
        `;
    });

    container.innerHTML = html;
}

async function handleRunSimulator() {
    const pName = document.getElementById('simulatorPlayerSelect').value;
    if (!pName) {
        showToast('Please select a player first.', 'warning');
        return;
    }

    const player = globalPlayers.find(p => p.player_name === pName);
    if (!player) return;

    const modifiedStats = { ...player };
    const simFields = ['batting_average', 'strike_rate', 'runs', 'recent_form_score'];

    simFields.forEach(f => {
        const slider = document.getElementById(`sim_${f}`);
        if (slider) modifiedStats[f] = parseFloat(slider.value);
    });

    const resultBox = document.getElementById('simulatorResultBox');
    resultBox.innerHTML = '<div class="p-4 text-center"><div class="spinner-border text-orange me-2"></div> Running What-If Simulation...</div>';

    try {
        const resOrig = await fetch('/api/predict', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ player_name: pName, model_choice: 'gb', input_stats: player })
        });

        const resMod = await fetch('/api/predict', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ player_name: pName, model_choice: 'gb', input_stats: modifiedStats })
        });

        const dataOrig = await resOrig.json();
        const dataMod = await resMod.json();

        if (resOrig.ok && resMod.ok) {
            const origVal = dataOrig.result.predictions.gb.value;
            const modVal = dataMod.result.predictions.gb.value;
            const diff = (modVal - origVal).toFixed(1);

            resultBox.innerHTML = `
                <div class="row g-3">
                    <div class="col-6">
                        <div class="p-3 text-center rounded-3 bg-light border">
                            <small class="text-muted">Original Baseline</small>
                            <h3 class="fw-bold text-dark mb-0">${origVal} Runs</h3>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="p-3 text-center rounded-3" style="background: #FFEDD5; border: 2px solid var(--orange);">
                            <small class="text-muted">Simulated Prediction</small>
                            <h3 class="fw-bold text-orange mb-0">${modVal} Runs</h3>
                        </div>
                    </div>
                </div>
                <div class="alert ${diff >= 0 ? 'alert-success' : 'alert-danger'} mt-3 mb-0 text-center fw-bold">
                    Impact Delta: ${diff >= 0 ? '+' : ''}${diff} Runs
                </div>
                <small class="text-muted d-block mt-3">This simulation demonstrates model feature sensitivity and does not guarantee future real match statistics.</small>
            `;
        }
    } catch (err) {
        resultBox.innerHTML = `<div class="alert alert-danger">Simulator error: ${err.message}</div>`;
    }
}

// Prediction History Loader & Filters
async function loadHistory() {
    try {
        const res = await fetch('/api/history');
        const data = await res.json();

        const tbody = document.getElementById('historyTableBody');
        if (!tbody) return;

        const history = data.history || [];

        if (history.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted py-4">No prediction history recorded yet.</td></tr>';
            return;
        }

        tbody.innerHTML = history.map(h => `
            <tr>
                <td>#${h.id}</td>
                <td class="fw-bold text-dark">${h.player_name}</td>
                <td><span class="badge ${h.model_used === 'XGBoost' ? 'badge-orange' : 'badge-purple'}">${h.model_used}</span></td>
                <td>${h.target_col}</td>
                <td class="fw-bold text-purple">${h.predicted_value}</td>
                <td class="small text-muted">${h.timestamp}</td>
            </tr>
        `).join('');

    } catch (err) {
        console.error("Error loading history:", err);
    }
}

function filterHistory() {
    const q = document.getElementById('historySearchInput').value.toLowerCase();
    const rows = document.querySelectorAll('#historyTableBody tr');
    rows.forEach(r => {
        const text = r.textContent.toLowerCase();
        r.style.display = text.includes(q) ? '' : 'none';
    });
}

function exportHistoryCSV() {
    window.location.href = '/api/history/export';
}
