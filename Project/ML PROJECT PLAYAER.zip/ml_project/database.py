import sqlite3
import os
import json
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'playerpulse.db')

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()

    # Datasets table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS datasets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT NOT NULL,
            filepath TEXT NOT NULL,
            row_count INTEGER,
            col_count INTEGER,
            target_col TEXT,
            target_desc TEXT,
            upload_date TEXT,
            is_sample INTEGER DEFAULT 0
        )
    ''')

    # Models table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS models (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            dataset_id INTEGER,
            target_col TEXT NOT NULL,
            task_type TEXT NOT NULL, -- 'regression' or 'classification'
            gb_metrics TEXT, -- JSON string
            xgb_metrics TEXT, -- JSON string
            best_model TEXT,
            created_at TEXT,
            feature_names TEXT -- JSON string list
        )
    ''')

    # Predictions table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            player_name TEXT,
            role TEXT,
            match_format TEXT,
            input_data TEXT, -- JSON string of input stats
            model_used TEXT, -- 'Gradient Boosting', 'XGBoost', or 'Both'
            predicted_value TEXT, -- e.g. "48.5 Runs" or "Class 1"
            target_col TEXT,
            prediction_date TEXT
        )
    ''')

    conn.commit()
    conn.close()

def save_dataset_meta(filename, filepath, row_count, col_count, target_col="next_match_runs", target_desc="Predicted runs scored in the next match", is_sample=0):
    conn = get_db_connection()
    cursor = conn.cursor()
    upload_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute('''
        INSERT INTO datasets (filename, filepath, row_count, col_count, target_col, target_desc, upload_date, is_sample)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', (filename, filepath, row_count, col_count, target_col, target_desc, upload_date, is_sample))
    conn.commit()
    dataset_id = cursor.lastrowid
    conn.close()
    return dataset_id

def get_latest_dataset():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM datasets ORDER BY id DESC LIMIT 1')
    row = cursor.fetchone()
    conn.close()
    if row:
        return dict(row)
    return None

def update_dataset_target(dataset_id, target_col, target_desc):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('UPDATE datasets SET target_col = ?, target_desc = ? WHERE id = ?', (target_col, target_desc, dataset_id))
    conn.commit()
    conn.close()

def save_trained_model(name, dataset_id, target_col, task_type, gb_metrics, xgb_metrics, best_model, feature_names):
    conn = get_db_connection()
    cursor = conn.cursor()
    created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute('''
        INSERT INTO models (name, dataset_id, target_col, task_type, gb_metrics, xgb_metrics, best_model, created_at, feature_names)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (name, dataset_id, target_col, task_type, json.dumps(gb_metrics), json.dumps(xgb_metrics), best_model, created_at, json.dumps(feature_names)))
    conn.commit()
    model_id = cursor.lastrowid
    conn.close()
    return model_id

def get_latest_model():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM models ORDER BY id DESC LIMIT 1')
    row = cursor.fetchone()
    conn.close()
    if row:
        d = dict(row)
        d['gb_metrics'] = json.loads(d['gb_metrics']) if d['gb_metrics'] else {}
        d['xgb_metrics'] = json.loads(d['xgb_metrics']) if d['xgb_metrics'] else {}
        d['feature_names'] = json.loads(d['feature_names']) if d['feature_names'] else []
        return d
    return None

def save_prediction(player_name, role, match_format, input_data, model_used, predicted_value, target_col):
    conn = get_db_connection()
    cursor = conn.cursor()
    prediction_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute('''
        INSERT INTO predictions (player_name, role, match_format, input_data, model_used, predicted_value, target_col, prediction_date)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', (player_name, role, match_format, json.dumps(input_data), model_used, str(predicted_value), target_col, prediction_date))
    conn.commit()
    pred_id = cursor.lastrowid
    conn.close()
    return pred_id

def get_predictions_history():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM predictions ORDER BY id DESC')
    rows = cursor.fetchall()
    conn.close()
    result = []
    for r in rows:
        item = dict(r)
        item['input_data'] = json.loads(item['input_data']) if item['input_data'] else {}
        result.append(item)
    return result

def get_dashboard_counts():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT COUNT(*) as count FROM predictions')
    pred_count = cursor.fetchone()['count']
    
    cursor.execute('SELECT COUNT(*) as count FROM models')
    model_count = cursor.fetchone()['count']

    latest_ds = get_latest_dataset()
    row_count = latest_ds['row_count'] if latest_ds else 0

    conn.close()
    return {
        'predictions_count': pred_count,
        'models_count': model_count,
        'row_count': row_count
    }

if __name__ == '__main__':
    init_db()
    print("Database initialized successfully.")
