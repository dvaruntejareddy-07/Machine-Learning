import os
import json
import csv
import io
from flask import Flask, render_template, request, jsonify, send_file, Response
from werkzeug.utils import secure_filename

import database
import ml_engine

# Pandas import fallback
PANDAS_OK = False
try:
    import pandas as pd
    import numpy as np
    PANDAS_OK = True
except Exception:
    PANDAS_OK = False

app = Flask(__name__)
app.config['SECRET_KEY'] = 'playerpulse-cricket-ml-secret'
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Initialize Database on startup
database.init_db()

def read_csv_data(filepath):
    if PANDAS_OK:
        try:
            df = pd.read_csv(filepath)
            return list(df.columns), df.replace({np.nan: None}).to_dict(orient='records')
        except Exception:
            pass

    rows = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for r in reader:
            rows.append(dict(r))
    headers = list(rows[0].keys()) if rows else []
    return headers, rows

# Pre-load sample dataset into DB if no dataset exists
def ensure_sample_loaded():
    latest = database.get_latest_dataset()
    sample_csv = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sample_cricket_data.csv')
    if not latest and os.path.exists(sample_csv):
        headers, rows = read_csv_data(sample_csv)
        dst_path = os.path.join(app.config['UPLOAD_FOLDER'], 'sample_cricket_data.csv')
        
        with open(dst_path, 'w', newline='', encoding='utf-8') as f:
            if rows:
                writer = csv.DictWriter(f, fieldnames=headers)
                writer.writeheader()
                writer.writerows(rows)

        database.save_dataset_meta(
            filename='sample_cricket_data.csv',
            filepath=dst_path,
            row_count=len(rows),
            col_count=len(headers),
            target_col='next_match_runs',
            target_desc='Predicted runs scored in the next match',
            is_sample=1
        )
        # Train default models
        try:
            res = ml_engine.train_and_evaluate(dst_path, 'next_match_runs')
            database.save_trained_model(
                name='Default Sample Model',
                dataset_id=1,
                target_col='next_match_runs',
                task_type=res['task_type'],
                gb_metrics=res['gb_metrics'],
                xgb_metrics=res['xgb_metrics'],
                best_model=res['best_model'],
                feature_names=res['feature_cols']
            )
        except Exception as e:
            print("Auto-training sample error:", e)

ensure_sample_loaded()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/stats', methods=['GET'])
def get_stats():
    counts = database.get_dashboard_counts()
    latest_model = database.get_latest_model()
    latest_ds = database.get_latest_dataset()

    chart_data = {"labels": [], "runs": [], "avg": [], "wickets": []}

    if latest_ds and os.path.exists(latest_ds['filepath']):
        try:
            headers, rows = read_csv_data(latest_ds['filepath'])
            sorted_rows = sorted(rows, key=lambda r: float(r.get('runs', 0) or 0), reverse=True)[:10]
            chart_data['labels'] = [r.get('player_name', 'Unknown') for r in sorted_rows]
            chart_data['runs'] = [float(r.get('runs', 0) or 0) for r in sorted_rows]
            chart_data['avg'] = [float(r.get('batting_average', 0) or 0) for r in sorted_rows]
            chart_data['wickets'] = [float(r.get('wickets', 0) or 0) for r in sorted_rows]
        except Exception as e:
            print("Chart data error:", e)

    return jsonify({
        'counts': counts,
        'has_model': latest_model is not None,
        'latest_model': latest_model,
        'latest_dataset': latest_ds,
        'chart_data': chart_data
    })

@app.route('/api/dataset', methods=['GET'])
def get_dataset_info():
    ds = database.get_latest_dataset()
    if not ds or not os.path.exists(ds['filepath']):
        return jsonify({'loaded': False, 'message': 'No active dataset found.'})

    headers, rows = read_csv_data(ds['filepath'])

    missing_vals = {h: 0 for h in headers}
    col_types = {h: 'numeric' for h in headers}

    for r in rows:
        for h in headers:
            v = r.get(h)
            if v is None or v == '':
                missing_vals[h] += 1

    preview = rows[:15]
    sample_rows = rows[:100]

    return jsonify({
        'loaded': True,
        'id': ds['id'],
        'filename': ds['filename'],
        'row_count': len(rows),
        'col_count': len(headers),
        'target_col': ds['target_col'] or 'next_match_runs',
        'target_desc': ds['target_desc'] or '',
        'is_sample': bool(ds['is_sample']),
        'columns': headers,
        'numeric_columns': headers,
        'column_types': col_types,
        'missing_values': missing_vals,
        'preview': preview,
        'sample_rows': sample_rows
    })

@app.route('/api/dataset/upload', methods=['POST'])
def upload_dataset():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part in request.'}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected.'}), 400

    if not file.filename.endswith('.csv'):
        return jsonify({'error': 'Only CSV files are supported.'}), 400

    filename = secure_filename(file.filename)
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(filepath)

    try:
        headers, rows = read_csv_data(filepath)
        if len(rows) < 5:
            return jsonify({'error': 'CSV must contain at least 5 rows for machine learning.'}), 400

        target_col = None
        if 'next_match_runs' in headers:
            target_col = 'next_match_runs'
        else:
            for c in headers:
                if c.startswith('next_') or c.startswith('target_'):
                    target_col = c
                    break
        if not target_col:
            target_col = headers[-1]

        target_desc = "Predict runs scored in the next match"

        ds_id = database.save_dataset_meta(
            filename=filename,
            filepath=filepath,
            row_count=len(rows),
            col_count=len(headers),
            target_col=target_col,
            target_desc=target_desc,
            is_sample=0
        )

        return jsonify({
            'success': True,
            'message': f"Dataset '{filename}' uploaded successfully with {len(rows)} rows!",
            'dataset_id': ds_id,
            'target_col': target_col,
            'target_desc': target_desc
        })
    except Exception as e:
        return jsonify({'error': f"Failed to parse CSV file: {str(e)}"}), 500

@app.route('/api/dataset/target', methods=['POST'])
def update_target():
    data = request.json or {}
    target_col = data.get('target_col')
    target_desc = data.get('target_desc') or "Predict runs scored in the next match"

    if not target_col or not str(target_col).strip():
        return jsonify({'error': 'Please select a valid non-empty target column.'}), 400

    ds = database.get_latest_dataset()
    if not ds:
        return jsonify({'error': 'No active dataset found.'}), 400

    headers, _ = read_csv_data(ds['filepath'])
    if target_col not in headers:
        return jsonify({'error': f"Selected column '{target_col}' does not exist in dataset."}), 400

    database.update_dataset_target(ds['id'], target_col, target_desc)
    return jsonify({'success': True, 'message': f"Target column updated to '{target_col}'!"})

@app.route('/api/dataset/load-sample', methods=['POST'])
def load_sample():
    sample_csv = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sample_cricket_data.csv')
    if not os.path.exists(sample_csv):
        return jsonify({'error': 'Sample dataset file not found.'}), 404

    headers, rows = read_csv_data(sample_csv)
    dst_path = os.path.join(app.config['UPLOAD_FOLDER'], 'sample_cricket_data.csv')

    with open(dst_path, 'w', newline='', encoding='utf-8') as f:
        if rows:
            writer = csv.DictWriter(f, fieldnames=headers)
            writer.writeheader()
            writer.writerows(rows)

    ds_id = database.save_dataset_meta(
        filename='sample_cricket_data.csv',
        filepath=dst_path,
        row_count=len(rows),
        col_count=len(headers),
        target_col='next_match_runs',
        target_desc='Predicted runs scored in the next match',
        is_sample=1
    )

    return jsonify({'success': True, 'message': 'Sample dataset loaded successfully!'})

@app.route('/api/dataset/template', methods=['GET'])
def download_template():
    sample_csv = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sample_cricket_data.csv')
    return send_file(sample_csv, as_attachment=True, download_name='playerpulse_sample_template.csv')

@app.route('/api/train', methods=['POST'])
def train_models():
    ds = database.get_latest_dataset()
    if not ds or not os.path.exists(ds['filepath']):
        return jsonify({'error': 'No active dataset available for training. Upload or load a dataset first.'}), 400

    target_col = ds['target_col'] or 'next_match_runs'

    try:
        meta = ml_engine.train_and_evaluate(ds['filepath'], target_col=target_col)

        database.save_trained_model(
            name=f"Model_{target_col}",
            dataset_id=ds['id'],
            target_col=target_col,
            task_type=meta['task_type'],
            gb_metrics=meta['gb_metrics'],
            xgb_metrics=meta['xgb_metrics'],
            best_model=meta['best_model'],
            feature_names=meta['feature_cols']
        )

        return jsonify({
            'success': True,
            'message': 'Gradient Boosting and XGBoost models trained successfully!',
            'metadata': meta
        })
    except Exception as e:
        return jsonify({'error': f"Model training failed: {str(e)}"}), 500

@app.route('/api/models/latest', methods=['GET'])
def get_latest_model():
    m = database.get_latest_model()
    if not m:
        return jsonify({'has_model': False})

    meta_path = os.path.join(ml_engine.MODELS_DIR, 'metadata.json')
    if os.path.exists(meta_path):
        with open(meta_path, 'r') as f:
            full_meta = json.load(f)
            m['feature_importance'] = full_meta.get('feature_importance', [])
            m['split_type'] = full_meta.get('split_type', '')
            m['best_reason'] = full_meta.get('best_reason', '')

    return jsonify({'has_model': True, 'model': m})

@app.route('/api/players', methods=['GET'])
def get_players():
    ds = database.get_latest_dataset()
    if not ds or not os.path.exists(ds['filepath']):
        return jsonify({'players': []})

    headers, rows = read_csv_data(ds['filepath'])
    return jsonify({'players': rows})

@app.route('/api/predict', methods=['POST'])
def predict():
    data = request.json or {}
    player_name = data.get('player_name', 'Custom Player')
    role = data.get('role', 'Batsman')
    match_format = data.get('match_format', 'ODI')
    model_choice = data.get('model_choice', 'both')
    input_stats = data.get('input_stats', {})

    try:
        res = ml_engine.predict_performance(input_stats, model_choice=model_choice)
        
        pred_val_str = ""
        if 'gb' in res['predictions'] and 'xgb' in res['predictions']:
            pred_val_str = f"GB: {res['predictions']['gb']['formatted']} | XGB: {res['predictions']['xgb']['formatted']}"
        elif 'gb' in res['predictions']:
            pred_val_str = f"GB: {res['predictions']['gb']['formatted']}"
        elif 'xgb' in res['predictions']:
            pred_val_str = f"XGB: {res['predictions']['xgb']['formatted']}"

        database.save_prediction(
            player_name=player_name,
            role=role,
            match_format=match_format,
            input_data=input_stats,
            model_used=model_choice.upper(),
            predicted_value=pred_val_str,
            target_col=res['target_col']
        )

        return jsonify({'success': True, 'result': res})
    except Exception as e:
        return jsonify({'error': f"Prediction failed: {str(e)}"}), 500

@app.route('/api/simulate', methods=['POST'])
def simulate_what_if():
    data = request.json or {}
    original_stats = data.get('original_stats', {})
    modified_stats = data.get('modified_stats', {})
    model_choice = data.get('model_choice', 'both')

    try:
        res_orig = ml_engine.predict_performance(original_stats, model_choice=model_choice)
        res_mod = ml_engine.predict_performance(modified_stats, model_choice=model_choice)

        changed_keys = []
        for k, v in modified_stats.items():
            if str(original_stats.get(k)) != str(v):
                changed_keys.append(k)

        return jsonify({
            'success': True,
            'changed_inputs': changed_keys,
            'original_prediction': res_orig['predictions'],
            'modified_prediction': res_mod['predictions'],
            'unit': res_orig['unit'],
            'target_col': res_orig['target_col'],
            'disclaimer': "This is a model sensitivity experiment and demonstrates how model outputs react to parameter changes. It does not guarantee real-world performance changes."
        })
    except Exception as e:
        return jsonify({'error': f"Simulation failed: {str(e)}"}), 500

@app.route('/api/compare', methods=['POST'])
def compare_players():
    data = request.json or {}
    player_names = data.get('player_names', [])

    ds = database.get_latest_dataset()
    if not ds or not os.path.exists(ds['filepath']):
        return jsonify({'error': 'No active dataset available.'}), 400

    headers, rows = read_csv_data(ds['filepath'])
    selected_players = [r for r in rows if r.get('player_name') in player_names]

    for p in selected_players:
        try:
            pred_res = ml_engine.predict_performance(p, model_choice='both')
            p['prediction'] = pred_res['predictions']
            p['target_unit'] = pred_res['unit']
        except Exception:
            p['prediction'] = None

    return jsonify({'success': True, 'players': selected_players})

@app.route('/api/history', methods=['GET'])
def get_history():
    history = database.get_predictions_history()
    return jsonify({'history': history})

@app.route('/api/history/export', methods=['GET'])
def export_history():
    history = database.get_predictions_history()
    
    output = io.StringIO()
    if history:
        keys = history[0].keys()
        dict_writer = csv.DictWriter(output, fieldnames=keys)
        dict_writer.writeheader()
        dict_writer.writerows(history)

    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-disposition": "attachment; filename=playerpulse_prediction_history.csv"}
    )

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5001))
    print(f"Starting PlayerPulse Flask Server on http://127.0.0.1:{port}...")
    app.run(host='127.0.0.1', port=port, debug=False)

